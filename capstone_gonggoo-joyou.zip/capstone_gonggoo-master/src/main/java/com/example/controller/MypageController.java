package com.example.controller;

import com.example.domain.Member;
import com.example.session.SessionConst;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

@Controller
public class MypageController {
    @GetMapping("/mypage")
    public String homeLogin(@SessionAttribute(name = SessionConst.LOGIN_MEMBER, required = false) Member loginMember, Model model) {

        if (loginMember == null) {
            return "home";
        }

        //세션이 유지되면 마이페이지로 이동
        model.addAttribute("member", loginMember);
        return "mypage";
    }
}
