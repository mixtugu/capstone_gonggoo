package com.example.controller;

import com.example.account.*;
import com.example.domain.Member;
import com.example.session.SessionConst;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class AccountController {
    private final AccountSharing ottSharing;
    private final ManagingParticipants ottManaging;

    public AccountController(AccountSharing ottSharing, ManagingParticipants ottManaging) {
        this.ottSharing = ottSharing;
        this.ottManaging = ottManaging;
    }

    @GetMapping("/accountIndex")
    public String accountIndex(Model model) {
        model.addAttribute("ottSharing", ottSharing);
        return "account/accountIndex"; // Updated path
    }

    @GetMapping("/createRoom")
    public String createRoom(Model model) {
        model.addAttribute("room", new Room());
        return "account/createRoom"; // Updated path
    }

    @PostMapping("/createRoom")
    public String createRoomSubmit(@ModelAttribute Room room, BindingResult result, Model model, HttpServletRequest request) {
        if (result.hasErrors()) {
            return "account/createRoom";
        }

        // 방 이름 중복 검사
        boolean roomExists = ottSharing.getRooms().stream()
                .anyMatch(existingRoom -> existingRoom.getName().equals(room.getName()));
        if (roomExists) {
            model.addAttribute("room", new Room());
            model.addAttribute("nameError", "동일한 이름의 방이 이미 존재합니다.");
            return "account/createRoom";
        }

        // 대표자 생성을 위해 세션에서 로그인한 사용자 정보를 가져옴
        HttpSession session = request.getSession(false);
        Member loginMember = (Member) session.getAttribute(SessionConst.LOGIN_MEMBER);
        // 로그인한 사용자 정보를 바탕으로 참여자 객체를 생성하여 대표자로 설정
        Representative representative = new Representative();
        representative.setName(loginMember.getName());
        room.setRepresentative(representative); //

        // 새로운 방을 생성하고 대표자를 설정
        ottSharing.createNewSharingRoom(room, representative);

        // OTT 이름이 "기타"일 경우, 사용자가 입력한 커스텀 OTT 이름을 설정
        String customOttName = request.getParameter("customOttName");
        if ("기타".equals(room.getOttName()) && customOttName != null && !customOttName.isEmpty()) {
            room.setOttName(customOttName);
        }

        return "redirect:/";
    }



    @GetMapping("/joinRoom/search")
    public String searchRooms(@RequestParam(name = "searchName", required = false) String searchName,
                              @RequestParam(name = "searchOtt", required = false) String searchOtt, Model model) {
        List<Room> filteredRooms = ottSharing.getRooms().stream()
                .filter(room -> (searchName == null || searchName.isEmpty() || room.getName().contains(searchName) || room.getOttName().contains(searchName)) &&
                        (searchOtt == null || searchOtt.isEmpty() || room.getOttName().equalsIgnoreCase(searchOtt) || "기타".equalsIgnoreCase(searchOtt) && !room.getOttName().equalsIgnoreCase("왓챠") && !room.getOttName().equalsIgnoreCase("라프텔") && !room.getOttName().equalsIgnoreCase("티빙")))
                .collect(Collectors.toList());

        model.addAttribute("rooms", filteredRooms);
        model.addAttribute("ottName", searchOtt);
        return "account/roomsByOtt"; // Updated path
    }


    @GetMapping("/joinRoom")
    public String joinRoom(@RequestParam(name = "selectedRoom", required = false) String selectedRoomName,
                           @RequestParam(name = "ottName", required = false) String ottName, Model model) {
        List<Room> rooms;
        if (ottName != null && !ottName.isEmpty()) {
            rooms = ottSharing.getRooms().stream()
                    .filter(room -> room.getOttName().equals(ottName))
                    .collect(Collectors.toList());
        } else {
            rooms = ottSharing.getRooms();
        }
        model.addAttribute("rooms", rooms);
        return "account/joinRoom"; // Updated path
    }


    @PostMapping("/joinRoom")
    public String joinRoomSubmit(@RequestParam("roomName") String roomName, HttpServletRequest request, Model model) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return "redirect:/login";
        }

        Member loginMember = (Member) session.getAttribute(SessionConst.LOGIN_MEMBER);
        if (loginMember == null) {
            return "redirect:/login";
        }

        // 방 이름으로 방을 찾음
        Room selectedRoom = ottSharing.getRooms().stream()
                .filter(room -> room.getName().equals(roomName))
                .findFirst()
                .orElse(null);

        if (selectedRoom == null) {
            model.addAttribute("error", "방을 찾을 수 없습니다");
            return "redirect:/joinRoom";
        }

        // 이미 참여자가 존재하는지 확인
        if (selectedRoom.isParticipantExists(loginMember.getName())) {
            model.addAttribute("error", "이미 참여한 방입니다");
            return "redirect:/roomDetails?roomName=" + roomName;
        }

        // 참여자를 추가
        Participant participant = new Participant();
        participant.setName(loginMember.getName());
        selectedRoom.addParticipant(participant);

        return "redirect:/roomDetails?roomName=" + roomName;
    }


    @GetMapping("/roomsByOtt")
    public String roomsByOtt(@RequestParam("ottName") String ottName, Model model) {
        List<Room> filteredRooms = ottSharing.getRooms().stream()
                .filter(room -> "기타".equals(ottName) ? !room.getOttName().equalsIgnoreCase("왓챠") && !room.getOttName().equalsIgnoreCase("라프텔") && !room.getOttName().equalsIgnoreCase("티빙") : room.getOttName().equalsIgnoreCase(ottName))
                .collect(Collectors.toList());

        model.addAttribute("rooms", filteredRooms);
        model.addAttribute("ottName", ottName);
        return "account/roomsByOtt"; // Updated path
    }

    @GetMapping("/roomDetails")
    public String roomDetails(@RequestParam("roomName") String roomName, Model model) {
        Room selectedRoom = ottSharing.getRooms().stream()
                .filter(room -> room.getName().equals(roomName))
                .findFirst()
                .orElse(null);

        if (selectedRoom != null) {
            model.addAttribute("room", selectedRoom);
            return "account/roomDetails"; // Updated path
        } else {
            model.addAttribute("error", "해당 방을 찾을 수 없습니다.");
            return "redirect:/";
        }
    }

    @GetMapping("/manageRooms")
    public String manageRooms(Model model) {
        model.addAttribute("rooms", ottSharing.getRooms());
        return "account/manageRooms"; // Updated path
    }

    @PostMapping("/manageRooms")
    public String manageRoomsSubmit(@ModelAttribute Room selectedRoom) {
        ottManaging.manageParticipantRooms(selectedRoom);
        return "redirect:/";
    }

    @GetMapping("/goBack")
    public String goBack(HttpServletRequest request) {
        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        } else {
            return "redirect:/";
        }
    }
}
