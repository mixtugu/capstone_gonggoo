package com.example.session;

public class SessionConst {
    public static final String LOGIN_MEMBER = "loginMember";

}
