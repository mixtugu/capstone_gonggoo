package com.example.account;

public class Participant {
    private String loginId;
    private String password;
    private String name;
    //private boolean paymentCompleted;

    // Constructors, getters, and setters
    public Participant() {
    }

    /*public Participant(String loginId, String password, String name) {
        this.loginId = loginId;
        this.password = password;
        this.name = name;
        this.paymentCompleted = false; // 기본값으로 false 설정
    }*/

    // Getter, setter methods
    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLoginId() {
        return loginId;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    /*public boolean isPaymentCompleted() {
        return paymentCompleted;
    }

    public void setPaymentCompleted(boolean paymentCompleted) {
        this.paymentCompleted = paymentCompleted;
    }*/
}
