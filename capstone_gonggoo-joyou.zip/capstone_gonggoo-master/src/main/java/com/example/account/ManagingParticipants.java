package com.example.account;

import com.example.account.AccountSharing;
import com.example.account.Room;
import com.example.account.Representative;
import com.example.account.Participant;
import org.springframework.stereotype.Component;
import java.util.Scanner;


@Component
public class ManagingParticipants {
    private AccountSharing accountSharing;

    public ManagingParticipants(AccountSharing accountSharing) {
        this.accountSharing = accountSharing;
    }

    public void manageParticipantRooms(Room selectedRoom) {
        Scanner scanner = new Scanner(System.in);
        /*System.out.println("참여하고 있는 방:");
        for (int i = 0; i < accountSharing.getRooms().size(); i++) {
            System.out.println((i + 1) + ". " + accountSharing.getRooms().get(i).getName());
        }

        System.out.println("관리할 방을 선택하시오:");
        int selectedRoomNumber = scanner.nextInt();

        if (selectedRoomNumber > 0 && selectedRoomNumber <= accountSharing.getRooms().size()) {
            Room room = accountSharing.getRooms().get(selectedRoomNumber - 1);

            if (room.getRepresentative().equals(accountSharing.getAccountProvider())) {
                System.out.println("당신은 이 방의 대표자입니다");

                accountSharing.requestPaymentConfirmation(room.getParticipants());
            } else {
                System.out.println("당신은 이 방의 참여자입니다");

                Representative representative = room.getRepresentative();
                if (representative != null) {
                    System.out.println("대표자에게 결제 확인 요청을 합니다 " + representative.getName());
                    confirmPaymentForParticipant(room, representative);
                } else {
                    System.out.println("대표자 없음");
                }
            }
        } else {
            System.out.println("다시 입력해주세요");
        }*/
    }

    /*private void confirmPaymentForParticipant(Room room, Representative representative) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("결제가 완료되었습니까?(y/n):");
        String choice = scanner.next();

        if (choice.equalsIgnoreCase("y")) {
            for (Participant participant : room.getParticipants()) {
                participant.setPaymentCompleted(true);
            }
            System.out.println("모든 참여자들의 결제가 완료되었습니다");
        } else {
            System.out.println("결제가 취소되었습니다.");
        }
    }*/
}