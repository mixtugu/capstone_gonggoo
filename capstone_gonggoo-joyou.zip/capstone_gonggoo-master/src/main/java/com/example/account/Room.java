package com.example.account;

import com.example.account.Participant;
import com.example.account.Representative;
import java.util.ArrayList;
import java.util.List;

public class Room {
    private String name;
    private String ottName;
    private String ottId;
    private String ottPassword;
    private int numberOfParticipants;
    private double payment;
    private Representative representative;
    private List<Participant> participants;

    public Room() {
        // Default constructor
        this.participants = new ArrayList<>();
    }

    public String getOttName() {
        return ottName;
    }

    public void setOttName(String ottName) {
        this.ottName = ottName;
    }


    public Room(String name, String ottName, int numberOfParticipants, double payment, Representative representative) {
        this.name = name;
        this.ottName = ottName; // ottName 초기화
        this.numberOfParticipants = numberOfParticipants;
        this.payment = payment;
        this.representative = representative;
        this.participants = new ArrayList<>();
    }

    /*public static class RoomNumber {
        private String selectedRoom;

        public String getSelectedRoom() {
            return selectedRoom;
        }

        public void setSelectedRoom(String selectedRoom) {
            this.selectedRoom = selectedRoom;
        }
    }*/

    // Getter, setter methods
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOttId() {
        return ottId;
    }

    public void setOttId(String ottId) {
        this.ottId = ottId;
    }

    public String getOttPassword() {
        return ottPassword;
    }

    public void setOttPassword(String ottPassword) {
        this.ottPassword = ottPassword;
    }

    public int getNumberOfParticipants() {
        return numberOfParticipants;
    }

    public void setNumberOfParticipants(int numberOfParticipants) {
        this.numberOfParticipants = numberOfParticipants;
    }

    public double getPayment() {
        return payment;
    }

    public void setPayment(double payment) {
        this.payment = payment;
    }

    public Representative getRepresentative() {
        return representative;
    }

    public void setRepresentative(Representative representative) {
        this.representative = representative;
    }

    public List<Participant> getParticipants() {
        return participants;
    }

    public void setParticipants(List<Participant> participants) {
        this.participants = participants;
    }

    public boolean addParticipant(Participant participant) {
        if (participants.size() < numberOfParticipants) {
            participants.add(participant);
            return true;
        }
        return false;
    }

    public boolean isParticipantExists(String participantName) {
        return participants.stream()
                .anyMatch(participant -> participant.getName().equals(participantName));
    }
}