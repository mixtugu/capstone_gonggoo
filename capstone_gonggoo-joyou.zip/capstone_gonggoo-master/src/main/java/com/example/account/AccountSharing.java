package com.example.account;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;


@Component
public class AccountSharing {
    private String ottName;
    @Setter
    private String accountProvider;
    @Getter
    private List<Room> rooms;

    public AccountSharing() {
        this.rooms = new ArrayList<>();
    }

    public void setOttName(String ottName) {
        this.ottName = ottName;
    }

    public String getAccountProvider() {
        return accountProvider;
    }


    public void createNewSharingRoom(Room room, Representative representative) {
        rooms.add(room);
    }


    /*public void requestPaymentConfirmation(List<Participant> participants) {
        System.out.println("참가자에게 결제 확인을 요청하는 중...");
        for (Participant participant : participants) {
            System.out.println("결제 재요청하기 " + participant.getName());
        }
    }*/

    /*public void provideAccountInformation() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("OTT 아이디와 비밀번호를 입력:");
        String ottId = scanner.next();
        String ottPassword = scanner.next();
        System.out.println("결제일자 입력:");
        String scheduledPaymentDate = scanner.next();

        System.out.println("참가자에게 계정 정보 제공합니다");
        System.out.println("참여한 OTT : " + ottName);
        System.out.println("OTT ID: " + ottId);
        System.out.println("OTT Password: " + ottPassword);
        System.out.println("결제일: " + scheduledPaymentDate);
    }

    public void confirmPaymentReceived() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("결제일을 입력하시오");
        double amount = scanner.nextDouble();
    }

    public void printInformation() {
        System.out.println("OTT: " + ottName);
        System.out.println("계정 제공자: " + accountProvider);
    }*/
}