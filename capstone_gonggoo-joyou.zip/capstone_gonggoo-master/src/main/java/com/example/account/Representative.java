package com.example.account;

import com.example.domain.Member;

public class Representative {
    private String loginId;
    private String password;
    private String name;
    //private int bankAccount;

    public Representative() {
    }
    public Representative(String loginId, String password, String name/*, int bankAccount*/) {
        this.loginId = loginId;
        this.password = password;
        this.name = name;
        //this.bankAccount = 0; //bankAccount;
    }



    // Getter methods
    public String getLoginId() {
        return loginId;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
    }

    /*public int getBankAccount() {
        return bankAccount;
    }*/
}
